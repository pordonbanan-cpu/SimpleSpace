package com.simplespace;

import com.simplespace.command.SpaceCommands;
import com.simplespace.event.SpaceTransitionHandler;
import com.simplespace.entity.ModEntities;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import org.slf4j.Logger;
import com.mojang.logging.LogUtils;

@Mod(SimpleSpace.MOD_ID)
public class SimpleSpace {
    public static final String MOD_ID = "simplespace";
    public static final Logger LOGGER = LogUtils.getLogger();

    public SimpleSpace(IEventBus modEventBus) {
        // Register dimensions, entities etc.
        ModEntities.register(modEventBus);

        modEventBus.addListener(this::commonSetup);
        modEventBus.addListener(this::clientSetup);

        // Register height-based transition + planet spawner
        NeoForge.EVENT_BUS.register(new SpaceTransitionHandler());
        NeoForge.EVENT_BUS.register(new com.simplespace.event.SpacePlanetSpawner());

        // Register commands /space and /overworld
        NeoForge.EVENT_BUS.addListener(this::onRegisterCommands);

        LOGGER.info("SimpleSpace mod loaded - reach Y=10000 to enter space!");
    }

    private void onRegisterCommands(RegisterCommandsEvent event) {
        SpaceCommands.register(event.getDispatcher());
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        LOGGER.info("SimpleSpace common setup complete");
    }

    private void clientSetup(final FMLClientSetupEvent event) {
        LOGGER.info("SimpleSpace client setup complete");
    }
}
