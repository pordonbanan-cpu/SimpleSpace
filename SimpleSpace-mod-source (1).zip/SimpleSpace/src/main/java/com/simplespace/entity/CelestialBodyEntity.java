package com.simplespace.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/**
 * Simple static celestial body (Sun, Earth, Moon).
 * No AI, no movement, just a big visual sphere.
 */
public class CelestialBodyEntity extends Entity {

    public CelestialBodyEntity(EntityType<? extends CelestialBodyEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setNoGravity(true);
        this.setInvulnerable(true);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        // No data needed for now
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        // Nothing extra
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        // Nothing extra
    }

    @Override
    public void tick() {
        // Completely static - do nothing
        this.setDeltaMovement(0, 0, 0);
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }
}
