package com.simplespace.entity;

import com.simplespace.SimpleSpace;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

public class ModEntities {

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, SimpleSpace.MOD_ID);

    // Celestial bodies as entities (static, large, no AI)
    public static final DeferredHolder<EntityType<?>, EntityType<CelestialBodyEntity>> SUN =
            ENTITIES.register("sun", () -> EntityType.Builder
                    .<CelestialBodyEntity>of(CelestialBodyEntity::new, MobCategory.MISC)
                    .sized(40.0f, 40.0f)          // Large size
                    .clientTrackingRange(256)
                    .updateInterval(Integer.MAX_VALUE)
                    .build("sun"));

    public static final DeferredHolder<EntityType<?>, EntityType<CelestialBodyEntity>> EARTH =
            ENTITIES.register("earth", () -> EntityType.Builder
                    .<CelestialBodyEntity>of(CelestialBodyEntity::new, MobCategory.MISC)
                    .sized(16.0f, 16.0f)
                    .clientTrackingRange(256)
                    .updateInterval(Integer.MAX_VALUE)
                    .build("earth"));

    public static final DeferredHolder<EntityType<?>, EntityType<CelestialBodyEntity>> MOON =
            ENTITIES.register("moon", () -> EntityType.Builder
                    .<CelestialBodyEntity>of(CelestialBodyEntity::new, MobCategory.MISC)
                    .sized(6.0f, 6.0f)
                    .clientTrackingRange(256)
                    .updateInterval(Integer.MAX_VALUE)
                    .build("moon"));

    public static void register(IEventBus bus) {
        ENTITIES.register(bus);
    }
}
