package com.simplespace.command;

import com.mojang.brigadier.CommandDispatcher;
import com.simplespace.dimension.ModDimensions;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;

public class SpaceCommands {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("space")
            .requires(source -> source.hasPermission(0)) // anyone can use
            .executes(context -> {
                ServerPlayer player = context.getSource().getPlayerOrException();
                ServerLevel space = player.server.getLevel(ModDimensions.SPACE_LEVEL);
                if (space != null) {
                    player.teleportTo(space, player.getX(), 128, player.getZ(), player.getYRot(), player.getXRot());
                    context.getSource().sendSuccess(() -> Component.literal("§bПереход в космос"), false);
                    return 1;
                }
                context.getSource().sendFailure(Component.literal("Измерение космоса не найдено"));
                return 0;
            })
        );

        dispatcher.register(Commands.literal("overworld")
            .requires(source -> source.hasPermission(0))
            .executes(context -> {
                ServerPlayer player = context.getSource().getPlayerOrException();
                ServerLevel overworld = player.server.getLevel(Level.OVERWORLD);
                if (overworld != null) {
                    player.teleportTo(overworld, player.getX(), 120, player.getZ(), player.getYRot(), player.getXRot());
                    context.getSource().sendSuccess(() -> Component.literal("§aВозврат в обычный мир"), false);
                    return 1;
                }
                return 0;
            })
        );
    }
}
