package com.simplespace.client;

import net.minecraft.client.renderer.DimensionSpecialEffects;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/**
 * Custom sky effects for the space dimension.
 * Makes the sky pure black with stars, no sun/moon cycle of the overworld.
 */
public class SpaceDimensionEffects extends DimensionSpecialEffects {

    public SpaceDimensionEffects() {
        // cloudLevel, hasGround, skyType
        super(Float.NaN, false, SkyType.NONE);
    }

    @Override
    public Vec3 getBrightnessDependentFogColor(Vec3 fogColor, float brightness) {
        // Almost no fog, pure black space
        return new Vec3(0.0, 0.0, 0.0);
    }

    @Override
    public boolean isFoggyAt(int x, int y) {
        return false; // no fog in space
    }

    // Optional: force dark ambient
    public float[] getSunriseColor(float timeOfDay, float partialTicks) {
        return null; // no sunrise/sunset
    }
}
