package com.simplespace.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.simplespace.entity.CelestialBodyEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.joml.Matrix4f;

/**
 * Simple sphere renderer for celestial bodies (Sun, Earth, Moon).
 * Draws a UV-sphere so planets look round.
 */
public class CelestialBodyRenderer extends EntityRenderer<CelestialBodyEntity> {

    private static final ResourceLocation SUN_TEXTURE =
            ResourceLocation.fromNamespaceAndPath("simplespace", "textures/entity/sun.png");
    private static final ResourceLocation EARTH_TEXTURE =
            ResourceLocation.fromNamespaceAndPath("simplespace", "textures/entity/earth.png");
    private static final ResourceLocation MOON_TEXTURE =
            ResourceLocation.fromNamespaceAndPath("simplespace", "textures/entity/moon.png");

    private final int segments = 24; // higher = smoother sphere

    public CelestialBodyRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public ResourceLocation getTextureLocation(CelestialBodyEntity entity) {
        String name = entity.getType().toShortString();
        if (name.contains("sun")) return SUN_TEXTURE;
        if (name.contains("earth")) return EARTH_TEXTURE;
        return MOON_TEXTURE;
    }

    @Override
    public void render(CelestialBodyEntity entity, float entityYaw, float partialTicks,
                       PoseStack poseStack, MultiBufferSource buffer, int packedLight) {

        poseStack.pushPose();

        // Scale the sphere according to entity size
        float scale = entity.getBbWidth() * 0.5f;
        poseStack.scale(scale, scale, scale);

        ResourceLocation texture = getTextureLocation(entity);
        VertexConsumer consumer = buffer.getBuffer(RenderType.entitySolid(texture));

        Matrix4f matrix = poseStack.last().pose();

        // Draw UV sphere
        for (int i = 0; i < segments; i++) {
            float lat0 = (float) Math.PI * (-0.5f + (float) i / segments);
            float lat1 = (float) Math.PI * (-0.5f + (float) (i + 1) / segments);

            float y0 = Mth.sin(lat0);
            float y1 = Mth.sin(lat1);
            float r0 = Mth.cos(lat0);
            float r1 = Mth.cos(lat1);

            for (int j = 0; j < segments; j++) {
                float lng0 = 2f * (float) Math.PI * (float) j / segments;
                float lng1 = 2f * (float) Math.PI * (float) (j + 1) / segments;

                float x00 = r0 * Mth.cos(lng0);
                float z00 = r0 * Mth.sin(lng0);
                float x01 = r0 * Mth.cos(lng1);
                float z01 = r0 * Mth.sin(lng1);
                float x10 = r1 * Mth.cos(lng0);
                float z10 = r1 * Mth.sin(lng0);
                float x11 = r1 * Mth.cos(lng1);
                float z11 = r1 * Mth.sin(lng1);

                float u0 = (float) j / segments;
                float u1 = (float) (j + 1) / segments;
                float v0 = (float) i / segments;
                float v1 = (float) (i + 1) / segments;

                // Two triangles per quad
                vertex(consumer, matrix, x00, y0, z00, u0, v0, packedLight);
                vertex(consumer, matrix, x10, y1, z10, u0, v1, packedLight);
                vertex(consumer, matrix, x11, y1, z11, u1, v1, packedLight);

                vertex(consumer, matrix, x00, y0, z00, u0, v0, packedLight);
                vertex(consumer, matrix, x11, y1, z11, u1, v1, packedLight);
                vertex(consumer, matrix, x01, y0, z01, u1, v0, packedLight);
            }
        }

        poseStack.popPose();
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }

    private void vertex(VertexConsumer consumer, Matrix4f matrix,
                        float x, float y, float z, float u, float v, int light) {
        consumer.addVertex(matrix, x, y, z)
                .setColor(255, 255, 255, 255)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(light)
                .setNormal(0, 1, 0);
    }
}
