package com.simplespace.event;

import com.simplespace.SimpleSpace;
import com.simplespace.dimension.ModDimensions;
import com.simplespace.entity.CelestialBodyEntity;
import com.simplespace.entity.ModEntities;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

/**
 * Spawns the static planets once when the first player enters the space dimension.
 */
public class SpacePlanetSpawner {

    private static boolean planetsSpawned = false;

    @SubscribeEvent
    public void onPlayerChangeDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getTo() != ModDimensions.SPACE_LEVEL) return;
        if (planetsSpawned) return;

        if (!(event.getEntity().level() instanceof ServerLevel spaceLevel)) return;

        // Spawn positions (far away so they look like real planets)
        spawnPlanet(spaceLevel, ModEntities.SUN.get(), 0, 200, 800);      // Sun far in front
        spawnPlanet(spaceLevel, ModEntities.EARTH.get(), -300, 150, -200); // Earth to the side
        spawnPlanet(spaceLevel, ModEntities.MOON.get(), -380, 140, -260);  // Moon near Earth

        planetsSpawned = true;
        SimpleSpace.LOGGER.info("Spawned static celestial bodies in space dimension");
    }

    private void spawnPlanet(ServerLevel level, net.minecraft.world.entity.EntityType<CelestialBodyEntity> type,
                             double x, double y, double z) {
        CelestialBodyEntity planet = type.create(level);
        if (planet != null) {
            planet.setPos(x, y, z);
            planet.setNoGravity(true);
            planet.setInvulnerable(true);
            level.addFreshEntity(planet);
        }
    }
}
