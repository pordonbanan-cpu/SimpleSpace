package com.simplespace.event;

import com.simplespace.SimpleSpace;
import com.simplespace.dimension.ModDimensions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

public class SpaceTransitionHandler {

    // Height in Overworld to enter space
    public static final int SPACE_HEIGHT = 10000;

    // If player falls below this Y in space → return to Overworld
    public static final int RETURN_HEIGHT = 0;

    @SubscribeEvent
    public void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (player.level().isClientSide()) return;

        Level level = player.level();

        // === Overworld → Space ===
        if (level.dimension() == Level.OVERWORLD) {
            if (player.getY() >= SPACE_HEIGHT) {
                ServerLevel spaceLevel = player.server.getLevel(ModDimensions.SPACE_LEVEL);
                if (spaceLevel != null) {
                    player.teleportTo(
                        spaceLevel,
                        player.getX(),
                        128.0,
                        player.getZ(),
                        player.getYRot(),
                        player.getXRot()
                    );
                    SimpleSpace.LOGGER.info("Player {} entered space", player.getName().getString());
                }
            }
        }

        // === Space → Overworld (reverse) ===
        else if (level.dimension() == ModDimensions.SPACE_LEVEL) {
            if (player.getY() < RETURN_HEIGHT) {
                ServerLevel overworld = player.server.getLevel(Level.OVERWORLD);
                if (overworld != null) {
                    // Return high in the sky so player doesn't immediately re-enter space
                    double returnY = SPACE_HEIGHT - 50; // slightly below the threshold
                    player.teleportTo(
                        overworld,
                        player.getX(),
                        returnY,
                        player.getZ(),
                        player.getYRot(),
                        player.getXRot()
                    );
                    SimpleSpace.LOGGER.info("Player {} returned from space to Overworld", player.getName().getString());
                }
            }
        }
    }
}
